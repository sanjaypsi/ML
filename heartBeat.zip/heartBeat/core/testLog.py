import logging
import os

log_dir = r"C:\InactivityService"
log_file = os.path.join(log_dir, "service.log")

# Ensure the log directory exists
if not os.path.exists(log_dir):
    os.makedirs(log_dir)

# Setup logging
logging.basicConfig(
    filename=log_file,
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s"
)

# Test writing to the log
logging.info("Test log entry.")

print("Log file exists:", os.path.exists(log_file))

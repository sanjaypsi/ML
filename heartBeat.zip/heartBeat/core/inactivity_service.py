# -*- coding: utf-8 -*-
# Inactivity Detector Service
# Author: Sanja
# Date: 2025-03-01

import win32serviceutil
import win32service
import win32event
import servicemanager
import logging
import threading
import time
from datetime import datetime
import os

from idle_reporter import IdleReporter
from event_detector import EventDetector
from connect_to_db import MongoDatabase


# Define log directory and ensure it exists
LOG_DIR = r"C:\Users\Public\InactivityService"
LOG_FILE = os.path.join(LOG_DIR, "service.log")

if not os.path.exists(LOG_DIR):
    os.makedirs(LOG_DIR)

# Manually create log file before initializing logging
with open(LOG_FILE, "a") as f:
    f.write("TEST: Service is starting...\n")

# Configure logging
logging.basicConfig(
    filename=LOG_FILE,
    level=logging.DEBUG,  # Set to DEBUG to capture more details
    format="%(asctime)s - %(levelname)s - %(message)s"
)
logging.info("Logging initialized.")


class InactivityService(win32serviceutil.ServiceFramework):
    _svc_name_ = "InactivityDetectorService"
    _svc_display_name_ = "Inactivity Detector Service"
    _svc_description_ = "Logs user activity and session state."

    def __init__(self, args):
        win32serviceutil.ServiceFramework.__init__(self, args)
        self.hWaitStop = win32event.CreateEvent(None, 0, 0, None)
        self.running = True
        self.reporter = IdleReporter()
        self.event_detector = EventDetector()
        self.db = MongoDatabase()
        self.last_event_signature = None

    def SvcStop(self):
        self.ReportServiceStatus(win32service.SERVICE_STOP_PENDING)
        self.running = False
        win32event.SetEvent(self.hWaitStop)
        logging.info("Service stopping...")

    def SvcDoRun(self):
        # Ensure log directory exists
        LOG_DIR = r"C:\Users\Public\InactivityService"
        LOG_FILE = os.path.join(LOG_DIR, "service.log")

        if not os.path.exists(LOG_DIR):
            os.makedirs(LOG_DIR)

        # Manually write to log file to confirm service is starting
        with open(LOG_FILE, "a") as f:
            f.write("TEST: Service started successfully.\n")

        #  FIX: Explicitly reset logging before reconfiguring
        for handler in logging.root.handlers[:]:
            logging.root.removeHandler(handler)

        logging.basicConfig(
            filename=LOG_FILE,
            level=logging.DEBUG,  # Capture detailed logs
            format="%(asctime)s - %(levelname)s - %(message)s"
        )

        logging.info("Logging is now working after reconfiguration!")

        # Start service threads
        logging.info("Starting Inactivity Detector Service...")
        monitor_thread = threading.Thread(target=self.reporter.monitor)
        monitor_thread.start()

        logout_thread = threading.Thread(target=self.monitor_user_sessions, daemon=True)
        logout_thread.start()

        event_thread = threading.Thread(target=self.log_events_loop, daemon=True)
        event_thread.start()

        while self.running:
            win32event.WaitForSingleObject(self.hWaitStop, 5000)


    def monitor_user_sessions(self):
        """Monitors user session state changes (active, disconnected, locked)."""
        try:
            import win32ts
        except ImportError:
            logging.error("win32ts module not found. Ensure pywin32 is installed.")
            return

        user_session_states = {}

        while self.running:
            try:
                sessions = win32ts.WTSEnumerateSessions(None, 1, 0)

                for session_id, _, _ in sessions:
                    try:
                        username = win32ts.WTSQuerySessionInformation(None, session_id, win32ts.WTSUserName)
                        state = win32ts.WTSQuerySessionInformation(None, session_id, win32ts.WTSConnectState)

                        if not username:
                            continue

                        prev_state = user_session_states.get(username)

                        if prev_state == win32ts.WTSActive and state == win32ts.WTSDisconnected:
                            self.set_user_status(username, "OFFLINE")
                        if prev_state == win32ts.WTSActive and state == win32ts.WTSLocked:
                            self.set_user_status(username, "LOCKED")

                        user_session_states[username] = state

                    except Exception:
                        pass

                time.sleep(10)

            except Exception as e:
                logging.exception("Error while monitoring session states")

    def set_user_status(self, username, status):
        # Stores user status in a file inside C:\Users\Public\InactivityService.
        try:
            base_dir = os.path.join(LOG_DIR, "users", username)
            status_file = os.path.join(base_dir, "status.txt")

            if not os.path.exists(base_dir):
                os.makedirs(base_dir)

            with open(status_file, 'w') as f:
                f.write(status.upper())

            logging.info(f"User {username} status set to {status.upper()}.")

        except Exception as e:
            logging.error(f"Error setting status '{status}' for {username}: {e}")

    def log_events_loop(self):
        """Continuously logs user activity from Event Logs."""
        while self.running:
            try:
                event = self.event_detector.get_latest_user_event()

                if event:
                    # Skip system services like UMFD-*, DWM-*
                    if event['username'].upper().startswith("UMFD-") or event['username'].upper().startswith("DWM-"):
                        continue

                    sig = (event['event_type'], event['username'], event['timestamp'])
                    if sig != self.last_event_signature:
                        logging.info(f"Status updated: {event['event_type']} by {event['username']}")

                        self.set_user_status(event['username'], event['event_type'].upper())
                        self.last_event_signature = sig

                        # === Push to DB ===
                        try:
                            entry = {
                                "username": event['username'],
                                "hostname": event['hostname'],
                                "event_type": event['event_type'].upper(),
                                "timestamp": datetime.now(),
                                "source": "event_detector"
                            }
                            self.db.insert_pulse(entry)
                            logging.info("Event pushed to DB.")
                        except Exception as db_err:
                            logging.warning(f"DB write failed: {db_err}")

                        # === Per-user idle_reporter.log ===
                        try:
                            user_profile = os.path.join("C:\\Users", event['username'])
                            user_log_dir = os.path.join(user_profile, "InactivityDetector")
                            os.makedirs(user_log_dir, exist_ok=True)
                            user_log_path = os.path.join(user_log_dir, "idle_reporter.log")

                            if event['event_type'].lower() != "logoff":
                                with open(user_log_path, "a") as f:
                                    f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S,%f')[:-3]} - INFO - Status updated: {event['event_type'].capitalize()} \n")
                        except Exception as e:
                            logging.warning(f"Could not write per-user event log: {e}")

            except Exception as e:
                logging.error(f"Event logging error: {e}")

            time.sleep(10)


if __name__ == '__main__':
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "debug":
        service = InactivityService(None)
        service.SvcDoRun()  # Run in foreground for debugging
    else:
        win32serviceutil.HandleCommandLine(InactivityService)

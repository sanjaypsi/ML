import numpy as np
import tensorflow as tf
import os

class ModelTrainer:
    def __init__(self, data_file, output_model_path):
        self.data_file          = data_file
        self.output_model_path  = output_model_path
        self.model              = None

    def load_data(self):
        with np.load(self.data_file) as data:
            X_train     = data['X_train']
            X_test      = data['X_test']
            y_train     = data['y_train']
            y_test      = data['y_test']
        return X_train, X_test, y_train, y_test

    def create_model(self, input_shape, num_classes):
        model = tf.keras.Sequential([
            tf.keras.layers.Input(shape=input_shape),
            tf.keras.layers.LSTM(64, return_sequences=True),
            tf.keras.layers.LSTM(32),
            tf.keras.layers.Dense(num_classes, activation='softmax')
        ])
        model.compile(optimizer ='adam',
                      loss      ='categorical_crossentropy',
                      metrics   =['accuracy'])
        return model

    def train_model(self, X_train, y_train, epochs=10, batch_size=32):
        input_shape = X_train.shape[1:]  # Shape should be (sequence_length, num_features)
        num_classes = y_train.shape[1]   # Number of classes for classification
        self.model  = self.create_model(input_shape, num_classes)
        history     = self.model.fit(X_train, y_train, epochs=epochs, batch_size=batch_size, validation_split=0.2)
        return history

    def evaluate_model(self, X_test, y_test):
        if self.model is None:
            raise ValueError("Model not trained. Please call 'train_model' first.")
        
        loss, accuracy = self.model.evaluate(X_test, y_test)
        print(f'Test loss: {loss}')
        print(f'Test accuracy: {accuracy}')
        return loss, accuracy

    def save_model(self):
        if self.model is None:
            raise ValueError("Model not trained. Please call 'train_model' first.")
        
        self.model.save(self.output_model_path)
        print(f'Model saved to {self.output_model_path}')

    def run(self):
        # Load data
        X_train, X_test, y_train, y_test = self.load_data()
        
        # Train the model
        self.train_model(X_train, y_train)
        
        # Evaluate the model
        self.evaluate_model(X_test, y_test)
        
        # Save the model
        self.save_model()

# Example usage
if __name__ == "__main__":
    data_file           = 'Tensorflow/data/exportdata/processed/processed_data.npz'
    output_model_path   = 'tensorflow_model.h5'
    trainer             = ModelTrainer(data_file, output_model_path)
    trainer.run()

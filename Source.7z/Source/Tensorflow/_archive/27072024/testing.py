import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler, OneHotEncoder, LabelEncoder
from sklearn.model_selection import train_test_split
from tensorflow.keras.utils import to_categorical

# Load the data
df = pd.read_csv('Tensorflow/data/exportdata/walk/Walking_A.csv')

# One-hot encode the 'JointName' column
one_hot_encoder = OneHotEncoder(sparse_output=False, drop='first')
joint_name_encoded = one_hot_encoder.fit_transform(df[['JointName']])
joint_name_encoded_df = pd.DataFrame(joint_name_encoded, columns=one_hot_encoder.get_feature_names_out(['JointName']))

# Combine the one-hot encoded 'JointName' with the numerical columns
df = pd.concat([df, joint_name_encoded_df], axis=1)

# Normalize numerical data
scaler = MinMaxScaler()
numerical_columns = ['Frame', 'TranslateX', 'TranslateY', 'TranslateZ', 'RotateX', 'RotateY', 'RotateZ']
df[numerical_columns] = scaler.fit_transform(df[numerical_columns])

# Prepare labels
label_encoder = LabelEncoder()
df['Label'] = label_encoder.fit_transform(df['Label'])
y = df['Label'].values
y_one_hot = to_categorical(y)

# Prepare features (excluding the original 'JointName' column and label)
feature_columns = numerical_columns + list(joint_name_encoded_df.columns)
X = df[feature_columns].values

# Reshape for LSTM (sequence length of 1)
X_reshaped = np.reshape(X, (X.shape[0], 1, X.shape[1]))

# Split the data
X_train, X_test, y_train, y_test = train_test_split(X_reshaped, y_one_hot, test_size=0.2, random_state=42)

# Print shapes to verify
print(f'X_train shape: {X_train.shape}')
print(f'X_test shape: {X_test.shape}')
print(f'y_train shape: {y_train.shape}')
print(f'y_test shape: {y_test.shape}')

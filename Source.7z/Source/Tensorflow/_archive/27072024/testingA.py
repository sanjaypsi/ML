import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler, LabelEncoder, OneHotEncoder
from sklearn.model_selection import train_test_split
from tensorflow.keras.utils import to_categorical
import os

class DataPreprocessor:
    def __init__(self, csv_directory, output_directory):
        self.csv_directory = csv_directory
        self.output_directory = output_directory
        self.numerical_columns = ['Frame', 'TranslateX', 'TranslateY', 'TranslateZ', 'RotateX', 'RotateY', 'RotateZ']
        self.one_hot_encoder = OneHotEncoder(sparse_output=False, drop='first')
        self.scaler = MinMaxScaler()
        self.label_encoder = LabelEncoder()
        
    def preprocess_file(self, file_path):
        df = pd.read_csv(file_path)
        
        # One-hot encode the 'JointName' column
        joint_name_encoded = self.one_hot_encoder.transform(df[['JointName']])
        joint_name_encoded_df = pd.DataFrame(joint_name_encoded, columns=self.one_hot_encoder.get_feature_names_out(['JointName']))
        
        # Combine the one-hot encoded 'JointName' with the numerical columns
        df = pd.concat([df, joint_name_encoded_df], axis=1)
        
        # Normalize numerical data
        df[self.numerical_columns] = self.scaler.transform(df[self.numerical_columns])
        
        # Encode labels
        df['Label'] = self.label_encoder.transform(df['Label'])
        
        return df

    def combine_data_frames(self, data_frames):
        return pd.concat(data_frames, ignore_index=True)

    def prepare_features_labels(self, df):
        feature_columns = self.numerical_columns + list(self.one_hot_encoder.get_feature_names_out(['JointName']))
        y = df['Label'].values
        y_one_hot = to_categorical(y)
        
        X = df[feature_columns].values
        X_reshaped = np.reshape(X, (X.shape[0], 1, X.shape[1]))
        
        return X_reshaped, y_one_hot

    def save_processed_data(self, X_train, X_test, y_train, y_test):
        os.makedirs(self.output_directory, exist_ok=True)
        np.save(os.path.join(self.output_directory, 'X_train.npy'), X_train)
        np.save(os.path.join(self.output_directory, 'X_test.npy'), X_test)
        np.save(os.path.join(self.output_directory, 'y_train.npy'), y_train)
        np.save(os.path.join(self.output_directory, 'y_test.npy'), y_test)
    
    def fit_encoders(self):
        # Fit encoders and scaler using the first file
        first_file_path = os.path.join(self.csv_directory, os.listdir(self.csv_directory)[0])
        df_first = pd.read_csv(first_file_path)
        self.one_hot_encoder.fit(df_first[['JointName']])
        self.scaler.fit(df_first[self.numerical_columns])
        self.label_encoder.fit(df_first['Label'])
    
    def run(self):
        # List all CSV files in the directory
        csv_files = [f for f in os.listdir(self.csv_directory) if f.endswith('.csv')]

        # Initialize list to hold processed DataFrames
        data_frames = []
        
        # Fit encoders and scaler
        self.fit_encoders()
        
        # Loop through each file, preprocess it, and append the DataFrame to the list
        for file in csv_files:
            file_path = os.path.join(self.csv_directory, file)
            df_processed = self.preprocess_file(file_path)
            data_frames.append(df_processed)
        
        # Combine all DataFrames
        combined_df = self.combine_data_frames(data_frames)
        
        # Prepare features and labels
        X, y_one_hot = self.prepare_features_labels(combined_df)
        
        # Split the data
        X_train, X_test, y_train, y_test = train_test_split(X, y_one_hot, test_size=0.2, random_state=42)
        
        # Save the processed data
        self.save_processed_data(X_train, X_test, y_train, y_test)
        
        # Print shapes to verify
        print(f'X_train shape: {X_train.shape}')
        print(f'X_test shape: {X_test.shape}')
        print(f'y_train shape: {y_train.shape}')
        print(f'y_test shape: {y_test.shape}')

# Example usage
if __name__ == "__main__":
    csv_directory = 'Tensorflow/data/exportdata/walk/'
    output_directory = 'Tensorflow/data/exportdata/processed/'
    preprocessor = DataPreprocessor(csv_directory, output_directory)
    preprocessor.run()

import numpy as np
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.preprocessing.sequence import TimeseriesGenerator
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense

# Example data: Replace with your actual data
# Assume each pose is a numpy array of shape (21, 3) and poses is a list of such arrays
poses = [np.random.rand(21, 3) for _ in range(1000)]  # Replace with actual poses

# Flatten each pose
flattened_poses = [pose.flatten() for pose in poses]

# Normalize the data
scaler = MinMaxScaler()
normalized_poses = scaler.fit_transform(flattened_poses)

# Reshape to sequences
sequence_length = 10  # Define sequence length
num_features    = 63  # 21 joints * 3 coordinates

# Create sequences for training
sequences = []
for i in range(len(normalized_poses) - sequence_length):
    sequences.append(normalized_poses[i:i + sequence_length])

sequences = np.array(sequences)

# Split into input-output pairs for LSTM
X = sequences[:, :-1, :]
y = sequences[:, -1, :]

# Build the model
model = Sequential([
    LSTM(128, activation='relu', input_shape=(sequence_length - 1, num_features)),
    Dense(num_features)
])

model.compile(optimizer='adam', loss='mse')
model.summary()

# Train the model
model.fit(X, y, epochs=50, batch_size=32)

# Function to generate in-between poses
def generate_in_between_poses(model, start_pose, middle_pose, end_pose, num_in_betweens):
    def interpolate_poses(pose1, pose2, steps):
        return [(pose1 + (pose2 - pose1) * (i / (steps + 1))) for i in range(1, steps + 1)]

    in_betweens = []

    # Interpolate from start to middle pose
    in_betweens += interpolate_poses(start_pose.flatten(), middle_pose.flatten(), num_in_betweens)

    # Interpolate from middle to end pose
    in_betweens += interpolate_poses(middle_pose.flatten(), end_pose.flatten(), num_in_betweens)

    # Reshape back to original pose shape
    in_betweens = [pose.reshape(21, 3) for pose in in_betweens]

    return np.array(in_betweens)

# Example poses (replace with actual poses)
start_pose = poses[0]  # Replace with actual start pose
middle_pose = poses[len(poses) // 2]  # Replace with actual middle pose
end_pose = poses[-1]  # Replace with actual end pose

num_in_betweens = 5  # Define how many in-between poses you want
in_between_poses = generate_in_between_poses(model, start_pose, middle_pose, end_pose, num_in_betweens)

# Reshape to 2D for inverse transform
in_between_poses_2d = in_between_poses.reshape(-1, num_features)

# Inverse transform to original scale
original_scale_poses = scaler.inverse_transform(in_between_poses_2d)

# Reshape back to 3D poses
final_poses = original_scale_poses.reshape(-1, 21, 3)

print("Generated in-between poses:")
print(final_poses)

# ==============================================================================
# predict the model
# ==============================================================================
from pyexpat import model
import re
from unittest import result
from tensorflow.keras.models import load_model
import numpy as np
import os

class ModelPredictor:
    def __init__(self, model_path, data_path):
        self.model_path = model_path
        self.data_path  = data_path
        
    def load_data(self):
        data = np.load(self.data_path)
        return data['X_test'], data['y_test']
    
    def load_model(self):
        return load_model(self.model_path)
    
    def predict(self):
        X_test, y_test = self.load_data()
        model = self.load_model()
        
        predictions = model.predict(X_test)
        print('Predictions shape:', predictions)
        return predictions

    def save_predictions(self, predictions):
        os.makedirs('predictions', exist_ok=True)
        np.savez_compressed(os.path.join('predictions', 'predictions.npz'), predictions=predictions)

    def run(self):
        predictions = self.predict()
        self.save_predictions(predictions)
        print('Predictions saved to predictions/predictions.npz')

# ======================================================================================
# Main
# ======================================================================================
if __name__ == '__main__':
    model_predictor = ModelPredictor(model_path='tensorflow_model.h5', data_path='processed_data.npz')
    model_predictor.run()
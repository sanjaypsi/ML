import numpy as np
import tensorflow as tf
import os
import pandas as pd
from sklearn.preprocessing import OneHotEncoder, MinMaxScaler
import joblib  # For saving and loading the encoder

class ModelTrainer:
    def __init__(self, data_file, output_model_path, encoder_file_path):
        self.data_file = data_file
        self.output_model_path = output_model_path
        self.encoder_file_path = encoder_file_path
        self.model = None
        self.numerical_columns = ['Frame', 'TranslateX', 'TranslateY', 'TranslateZ', 'RotateX', 'RotateY', 'RotateZ']
        self.one_hot_encoder = OneHotEncoder(sparse_output=False, drop='first')  # Initialize encoder

    def load_data(self):
        with np.load(self.data_file) as data:
            X_train = data['X_train']
            X_test = data['X_test']
            y_train = data['y_train']
            y_test = data['y_test']
        return X_train, X_test, y_train, y_test

    def fit_encoder(self, df):
        # Fit the encoder on the categorical column
        self.one_hot_encoder.fit(df[['JointName']])

    def create_model(self, input_shape, num_classes):
        model = tf.keras.Sequential([
            tf.keras.layers.Input(shape=input_shape),
            tf.keras.layers.LSTM(64, return_sequences=True),
            tf.keras.layers.LSTM(32),
            tf.keras.layers.Dense(num_classes, activation='softmax')
        ])
        model.compile(optimizer='adam',
                      loss='categorical_crossentropy',
                      metrics=['accuracy'])
        return model

    def train_model(self, X_train, y_train, original_df, epochs=10, batch_size=32):
        self.fit_encoder(original_df)  # Fit encoder on original data
        
        input_shape = X_train.shape[1:]  # Shape should be (sequence_length, num_features)
        num_classes = y_train.shape[1]   # Number of classes for classification
        
        self.model = self.create_model(input_shape, num_classes)
        
        history = self.model.fit(X_train, y_train, epochs=epochs, batch_size=batch_size, validation_split=0.2)
        return history

    def evaluate_model(self, X_test, y_test):
        if self.model is None:
            raise ValueError("Model not trained. Please call 'train_model' first.")
        
        loss, accuracy = self.model.evaluate(X_test, y_test)
        print(f'Test loss: {loss}')
        print(f'Test accuracy: {accuracy}')
        return loss, accuracy

    def save_model(self):
        if self.model is None:
            raise ValueError("Model not trained. Please call 'train_model' first.")
        
        self.model.save(self.output_model_path)
        print(f'Model saved to {self.output_model_path}')
        
        # Save the encoder
        joblib.dump(self.one_hot_encoder, self.encoder_file_path)
        print(f'Encoder saved to {self.encoder_file_path}')

    def load_model(self):
        if os.path.exists(self.output_model_path):
            self.model = tf.keras.models.load_model(self.output_model_path)
            print(f'Model loaded from {self.output_model_path}')
        else:
            raise FileNotFoundError(f'Model file not found at {self.output_model_path}')

        # Load the encoder
        if os.path.exists(self.encoder_file_path):
            self.one_hot_encoder = joblib.load(self.encoder_file_path)
            print(f'Encoder loaded from {self.encoder_file_path}')
        else:
            raise FileNotFoundError(f'Encoder file not found at {self.encoder_file_path}')

    def predict(self, X_new):
        if self.model is None:
            raise ValueError("Model not trained or loaded. Please call 'train_model' or 'load_model' first.")
        
        # Ensure the input shape matches the model's input shape
        X_new = np.array(X_new)
        if X_new.shape[1:] != self.model.input_shape[1:]:
            raise ValueError(f"Input shape mismatch. Expected: {self.model.input_shape[1:]}, Got: {X_new.shape[1:]}")
        
        predictions = self.model.predict(X_new)
        return predictions

    def predict_by_label(self, label, original_df):
        if self.model is None:
            raise ValueError("Model not trained or loaded. Please call 'train_model' or 'load_model' first.")
        
        # Ensure the label is in the original DataFrame
        if label not in original_df['Label'].values:
            raise ValueError(f"Label {label} not found in the data.")
        
        # Filter data by the specific label
        df_filtered = original_df[original_df['Label'] == label]
        
        # Extract and preprocess features
        feature_columns = self.numerical_columns + list(self.one_hot_encoder.get_feature_names_out(['JointName']))
        
        # Ensure columns match
        missing_columns = [col for col in feature_columns if col not in df_filtered.columns]
        if missing_columns:
            raise KeyError(f"Missing columns in DataFrame: {missing_columns}")
        
        # Extract features
        X_filtered = df_filtered[feature_columns]
        
        # Apply the same preprocessing as used during training
        X_filtered_scaled = MinMaxScaler().fit_transform(X_filtered[self.numerical_columns])
        X_filtered_encoded = self.one_hot_encoder.transform(df_filtered[['JointName']])
        
        # Combine the scaled numerical features with the one-hot encoded features
        X_filtered_preprocessed = np.hstack((X_filtered_scaled, X_filtered_encoded))
        
        # Reshape for LSTM (sequence length of 1)
        X_filtered_preprocessed = np.reshape(X_filtered_preprocessed, (X_filtered_preprocessed.shape[0], 1, X_filtered_preprocessed.shape[1]))
        
        # Predict using the model
        predictions = self.model.predict(X_filtered_preprocessed)
        return predictions

    def run(self):
        # Load data
        X_train, X_test, y_train, y_test = self.load_data()
        
        # Load the original data for fitting the encoder
        original_df = pd.read_csv('Tensorflow/data/exportdata/walk/Walking_A.csv')  # Adjust path as needed
        
        # Train the model
        self.train_model(X_train, y_train, original_df)
        
        # Evaluate the model
        self.evaluate_model(X_test, y_test)
        
        # Save the model and encoder
        self.save_model()

# Example usage
if __name__ == "__main__":
    data_file = 'Tensorflow/data/exportdata/processed/processed_data.npz'
    output_model_path = 'tensorflow_model.h5'
    encoder_file_path = 'one_hot_encoder.pkl'
    
    trainer = ModelTrainer(data_file, output_model_path, encoder_file_path)
    trainer.run()
    
    # Load the model and encoder
    trainer.load_model()
    
    # Example prediction by label
    original_df = pd.read_csv('Tensorflow/data/exportdata/walk/Walking_A.csv')  # Load original data
    label = 'walkingA'  # Example label
    predictions = trainer.predict_by_label(label, original_df)
    print(f"Predictions for label {label}:", predictions)

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout
import csv
import os

# Load the CSV file into a DataFrame
# Path to the CSV file
scriptpath      = os.path.dirname(__file__)  # This assumes the script is in the same directory as the CSV file
csv_file_path   = os.path.join(scriptpath, 'data', 'positions.csv')
# Load the CSV file into a DataFrame
df = pd.read_csv(csv_file_path)

# Extract the position columns (x, y, z)
positions = df[['x', 'y', 'z']].values

# Normalize the position data
scaler = StandardScaler()
normalized_positions = scaler.fit_transform(positions)
print(normalized_positions)

# # Prepare the input sequences (frames 1-39) and the corresponding output (frame 40)
# sequence_length = 99
# X = []
# y = []

# for i in range(len(normalized_positions) - sequence_length):
#     X.append(normalized_positions[i:i + sequence_length])
#     y.append(normalized_positions[i + sequence_length])

# X = np.array(X)
# y = np.array(y)

# # Display shapes of input and output arrays
# print('X shape:', X.shape)  # Should be (number of sequences, 39, 3)
# print('y shape:', y.shape)  # Should be (number of sequences, 3)

# # # Define the LSTM model
# # model = Sequential([
# #     LSTM(100, input_shape=(sequence_length, 3)),
# #     Dense(3)
# # ])
# model = Sequential([
#     LSTM(200, return_sequences=True, input_shape=(sequence_length, 3)),
#     Dropout(0.5),
#     LSTM(100),
#     Dropout(0.2),
#     Dense(3)
# ])
# # model = Sequential()
# # model.add(LSTM(100, activation='relu', input_shape=(3, 3)))
# # model.add(Dense(3))
# # model.compile(optimizer='adam', loss='mse')
# # # Compile the model
# model.compile(optimizer='adam', loss='mse')

# # Train the model
# # model.fit(X, y, epochs=100, verbose=100)
# model.fit(X, y, epochs=200, verbose=1)

# # Predict the position at frame 41 based on frames 2-40
# predicted_positions = []

# # Start with the last sequence from the training data
# input_sequence = normalized_positions[-sequence_length:]

# for _ in range(100):  # Predict 10 frames (41 to 50)
#     input_sequence = input_sequence.reshape((1, sequence_length, 3))
#     predicted_position = model.predict(input_sequence)
#     predicted_positions.append(predicted_position[0])
#     # Update the input sequence to include the new prediction
#     input_sequence = np.append(input_sequence[0][1:], predicted_position, axis=0)

# # # Denormalize the predicted positions
# # predicted_positions = scaler.inverse_transform(predicted_positions)

# # Denormalize the predicted positions
# predicted_positions = scaler.inverse_transform(predicted_positions)

# # Save the predicted positions to a CSV fil
# csv_file_path           = os.path.join(scriptpath, 'data', 'predicted_positions.csv')
# predicted_csv_file_path = csv_file_path

# # Display the predicted positions
# for i, pos in enumerate(predicted_positions, start=101):
#     print(f"Frame {i}: {pos}")

# with open(predicted_csv_file_path, 'w', newline='') as file:
#     writer = csv.writer(file)
#     writer.writerow(["frame", "x", "y", "z"])
#     for i, pos in enumerate(predicted_positions, start=101):
#         writer.writerow([i, pos[0], pos[1], pos[2]])

# print(f"Predicted positions saved to {predicted_csv_file_path}")
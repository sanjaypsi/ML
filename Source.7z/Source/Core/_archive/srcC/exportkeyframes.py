import maya.cmds as cmds
import csv
import os

# CSV file path to save the position data
scriptpath      = os.path.dirname(__file__)  # This assumes the script is in the same directory as the CSV file
csv_file_path   = os.path.join(scriptpath, 'data', 'positions.csv')

def export_keyframes(sphere_name):
    # Frames range
    start_frame = 1
    end_frame = 100


    # Collect position data
    position_data = []

    for frame in range(start_frame, end_frame + 1):
        cmds.currentTime(frame)
        position = cmds.xform(sphere_name, query=True, translation=True, worldSpace=True)
        position_data.append([frame] + position)

    # Save the data to CSV
    with open(csv_file_path, 'w', newline='') as file:
        writer = csv.writer(file)
        writer.writerow(["frame", "x", "y", "z"])
        writer.writerows(position_data)

    print(f"Position data saved to {csv_file_path}")
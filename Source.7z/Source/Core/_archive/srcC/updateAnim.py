''' 
Step 4: Using the Model to Generate Animation
Load the trained model and generate predictions.
Apply these predictions as keyframes in Maya.
Here's an example script to apply the predictions:

from importlib import reload
from Core import updateAnim
reload(updateAnim)
updateAnim.update_animation(object_name)

'''

import maya.cmds as cmds
import csv
import os

# Ensure the script is in the same directory as the model
scriptpath = os.path.dirname(os.path.realpath(__file__))
predicted_csv_file_path = os.path.join(scriptpath, 'data', 'predicted_positions.csv')

def update_animation(object_name):
    # Path to the CSV file containing the predictions
    # predicted_csv_file_path = 'C:/path/to/your/predicted_positions.csv'

    # Read the CSV file
    predictions = []
    with open(predicted_csv_file_path, 'r') as file:
        reader = csv.DictReader(file)
        for row in reader:
            frame = int(row['frame'])
            x = float(row['x'])
            y = float(row['y'])
            z = float(row['z'])
            predictions.append((frame, x, y, z))

    # Create a sphere or use an existing one
    if not cmds.objExists(object_name):
        cmds.polySphere(name=object_name)

    # Apply the predicted positions to the sphere
    for frame, x, y, z in predictions:
        cmds.currentTime(frame)
        cmds.setKeyframe(object_name, attribute='translateX', value=x)
        cmds.setKeyframe(object_name, attribute='translateY', value=y)
        cmds.setKeyframe(object_name, attribute='translateZ', value=z)

    # Playback the animation to see the result
    # cmds.play(forward=True)



import maya.cmds as cmds
import json
import os

# Path to save the JSON file
scriptpath = os.path.dirname(__file__)  # This assumes the script is in the same directory as the JSON file
filepath = os.path.join(scriptpath, 'data', 'positions.json')

def _animation_data():
    animation_data = {}
    
    # Get all joints or controls involved in the walk cycle animation
    all_objects = cmds.ls(type='joint')
    
    if not all_objects:
        cmds.warning("No joints found in the scene.")
        return animation_data
    
    for obj in all_objects:
        keyframes = cmds.keyframe(obj, query=True)
        
        if keyframes:
            animation_data[obj] = {}
            for attr in ['translateX', 'translateY', 'translateZ', 
                         'rotateX', 'rotateY', 'rotateZ', 
                         'scaleX', 'scaleY', 'scaleZ']:
                key_values = cmds.keyframe(obj, attribute=attr, query=True, valueChange=True)
                key_times = cmds.keyframe(obj, attribute=attr, query=True, timeChange=True)
                
                if key_values and key_times:
                    animation_data[obj][attr] = [{'time': time, 'value': value} for time, value in zip(key_times, key_values)]
    
    return animation_data

def export_to_json():
    animation_data = _animation_data()
    if not animation_data:
        cmds.warning("No animation data found to export.")
        return
    
    try:
        with open(filepath, 'w') as json_file:
            json.dump(animation_data, json_file, indent=4)
        cmds.confirmDialog(title='Export Successful', message=f'Animation data successfully exported to {filepath}', button=['OK'])
    except IOError as e:
        cmds.error(f"Failed to write JSON file: {e}")

# To run the export
export_to_json()



# Run the export function
#export_to_json('C:/path_to_save/walk_cycle_animation.json')
# from importlib import reload
# from Core import get_animation_data
# reload(get_animation_data)
# get_animation_data.export_to_json()
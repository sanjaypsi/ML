import json
import numpy as np
import os

scriptpath  = os.path.dirname(__file__)  # This assumes the script is in the same directory as the CSV file
_file       = os.path.join(scriptpath, 'data', 'keyframe_data.json')

'''
from importlib import reload
from Core import generate_keyframe_data
reload(generate_keyframe_data)

joint_order     = ['joint1', 'joint2', 'joint3', ...]  # List of joints
predictions     = np.random.rand(100, len(joint_order) * 6)  # Random predictions
keyframe_data   = generate_keyframe_data.generateKeyframe_data(predictions, joint_order)
generate_keyframe_data.save_keyframe_data(keyframe_data, _file)

'''


def generateKeyframe_data(predictions, joint_order):
    keyframe_data = []

    for frame in range(predictions.shape[0]):
        frame_data = {}
        for i, joint in enumerate(joint_order):
            translation = predictions[frame, i * 6: i * 6 + 3].tolist()
            rotation = predictions[frame, i * 6 + 3: i * 6 + 6].tolist()
            frame_data[joint] = {'translate': translation, 'rotate': rotation}
        keyframe_data.append(frame_data)

    return keyframe_data

def save_keyframe_data(keyframe_data, file_path):
    with open(file_path, 'w') as f:
        json.dump(keyframe_data, f, indent=4)


##=======================================================================================================================
##=======================================================================================================================
import json
from maya import cmds

def export_keyframes(file_path):
    joints = cmds.ls(type='joint')
    keyframe_data = {}
    
    for joint in joints:
        keyframe_data[joint] = {'translate': [], 'rotate': []}
        times = cmds.keyframe(joint, query=True, timeChange=True)
        print('times:', times)
        if not times:
            continue

        else:
            for time in times:
                cmds.currentTime(time)
                translation = cmds.getAttr(joint + '.translate')[0]
                rotation = cmds.getAttr(joint + '.rotate')[0]
                
                keyframe_data[joint]['translate'].append(translation)
                keyframe_data[joint]['rotate'].append(rotation)
    
    with open(file_path, 'w') as f:
        json.dump(keyframe_data, f, indent=4)

# export_keyframes(_file)
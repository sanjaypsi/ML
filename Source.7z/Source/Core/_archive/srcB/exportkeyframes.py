'''Create the ball animation manually in Maya and export the keyframe data.
Export Keyframe Data: Use Maya's Python scripting to export keyframe data to a CSV file.
Here's a sample script to export keyframe data:

from importlib import reload
from Core import exportkeyframes
reload(exportkeyframes)
exportkeyframes.export_keyframes('pSphere1')

'''

import maya.cmds as cmds
import csv
import os

# Define the path to save the CSV file
scriptpath = os.path.dirname(__file__)  # This assumes the script is in the same directory as the CSV file
csv_file = os.path.join(scriptpath, 'data', 'keyframes.csv')

def export_keyframes(object_name):
    # Check if the object exists
    if not cmds.objExists(object_name):
        cmds.warning(f"Object '{object_name}' does not exist.")
        return
    
    # Query keyframe data
    keyframes = cmds.keyframe(object_name, query=True, timeChange=True)
    positions = cmds.keyframe(object_name, query=True, valueChange=True)

    # Write to CSV
    with open(csv_file, 'w', newline='') as csvfile:
        csv_writer = csv.writer(csvfile)  # Use csv_writer instead of csv to avoid conflict
        csv_writer.writerow(['time', 'position'])
        csv_writer.writerows(zip(keyframes, positions))

    print(f"Keyframes exported successfully to {csv_file}")

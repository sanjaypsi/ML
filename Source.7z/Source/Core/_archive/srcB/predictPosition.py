'''Load the data from the CSV file.
Train a simple model to predict the position of the ball at each frame.
Here's an example script:


from importlib import reload
from Core import predictPosition
reload(predictPosition)
predictPosition.generate_data('')
'''

import tensorflow as tf
import numpy as np
import pandas as pd

import os
# Define the path to save the CSV file
scriptpath  = os.path.dirname(__file__)  # This assumes the script is in the same directory as the CSV file
csv_file    = os.path.join(scriptpath, 'data', 'keyframes.csv')

def generate_data():
    # Load data
    data = pd.read_csv(csv_file)
    times = data['time'].values
    positions = data['position'].values

    # Normalize data
    times = times / max(times)
    positions = positions / max(positions)

    # Prepare data for training
    X_train = np.array(times).reshape(-1, 1)
    y_train = np.array(positions)

    # Build model
    model = tf.keras.Sequential([
        tf.keras.layers.Dense(10, activation='relu', input_shape=(1,)),
        tf.keras.layers.Dense(10, activation='relu'),
        tf.keras.layers.Dense(1)
    ])

    model.compile(optimizer='adam', loss='mse')

    # Train model
    model.fit(X_train, y_train, epochs=100)

    # Save model
    ball_animation_model = os.path.join(scriptpath, 'data', 'ball_animation_model.keras')
    model.save(ball_animation_model)

generate_data()
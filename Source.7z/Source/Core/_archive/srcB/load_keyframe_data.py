import json
import numpy as np
import os
import tensorflow as tf


scriptpath  = os.path.dirname(__file__)  # This assumes the script is in the same directory as the CSV file
_file       = os.path.join(scriptpath, 'data', 'keyframe_data.json')

def load_keyframe_data(file_path):
    with open(file_path, 'r') as f:
        keyframe_data = json.load(f)
    
    # Extract joint names
    joints = list(keyframe_data.keys())
    
    # Extract keyframe data
    translations = []
    rotations = []
    
    for joint in joints:
        translations.append(keyframe_data[joint]['translate'])
        rotations.append(keyframe_data[joint]['rotate'])
    
    translations = np.array(translations)
    rotations = np.array(rotations)
    
    return translations, rotations

translations, rotations = load_keyframe_data(_file)

# translations, rotations  data write the code that train ML model
# Normalize the data
def normalize_data(data):
    mean = np.mean(data, axis=0)
    std = np.std(data, axis=0)
    epsilon = 1e-8
    normalized_data = (data - mean) / (std + epsilon)
    return normalized_data

def create_sequences(data, timesteps):
    sequences = []
    for i in range(len(data) - timesteps):
        sequences.append(data[i:i + timesteps])
    return np.array(sequences)

# Normalize data
normalized_translations = normalize_data(translations)
normalized_rotations = normalize_data(rotations)

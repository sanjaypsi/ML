''' 
Step 4: Using the Model to Generate Animation
Load the trained model and generate predictions.
Apply these predictions as keyframes in Maya.
Here's an example script to apply the predictions:

from importlib import reload
from Core import updateAnim
reload(updateAnim)
updateAnim.update_animation('pSphere1')

'''
import tensorflow as tf
import numpy as np
import maya.cmds as cmds
import os

# Ensure the script is in the same directory as the model
scriptpath = os.path.dirname(os.path.realpath(__file__))
ball_animation_model = os.path.join(scriptpath, 'data', 'ball_animation_model.keras')

def update_animation(object_name):
    try:
        # Load the trained model
        model = tf.keras.models.load_model(ball_animation_model)
    except Exception as e:
        print(f"Error loading model: {e}")
        return

    # Generate keyframe predictions
    times = np.linspace(0, 1, 50)  # Generate 100 frames
    predictions = model.predict(times.reshape(-1, 1))

    try:
        # Apply keyframes in Maya
        cmds.select(object_name)
        for time, position in zip(times, predictions):
            # Ensure position is a float value
            if isinstance(position, np.ndarray):
                position_value = position[0]
            else:
                position_value = position
            
            cmds.setKeyframe(object_name, time=time*100, attribute='translateX', value=position_value*10)
            cmds.setKeyframe(object_name, time=time*100, attribute='translateY', value=position_value*10)
            cmds.setKeyframe(object_name, time=time*100, attribute='translateZ', value=position_value*10)

    except Exception as e:
        print(f"Error setting keyframes: {e}")

# Example usage
# update_animation('pSphere1')  # Ensure 'pSphere1' exists in the Maya scene



# basice ball animation

# from importlib import reload
# from Core import basicML
# reload(basicML)
# basicML()

import maya.cmds as cmds

# ----------------------------------------------------------------------------------------------
# extract a basic ball animation
# ----------------------------------------------------------------------------------------------
import maya.cmds as cmds

def extract_animation_data(object_name):
	# Get all keyframes for the given object
	keyframes = cmds.keyframe(object_name, query=True, timeChange=True)
	animation_data = []

	for keyframe in keyframes:
		# Get translation values at each keyframe (ensure 3D translation)
		translation = cmds.getAttr(f'{object_name}.translate', time=keyframe)[0]
		if len(translation) == 3:
			animation_data.append((keyframe, translation))

	return animation_data

# ----------------------------------------------------------------------------------------------
# Preprocess the data for training
# ----------------------------------------------------------------------------------------------
import numpy as np
from sklearn.model_selection import train_test_split

def preprocess_data(animation_data):
	# Separate time and translation values
	times           = np.array([time for time, _ in animation_data]).reshape(-1, 1)
	translations    = np.array([translation for _, translation in animation_data])
	
	# Normalize the data (optional)
	times           = times / np.max(times)
	translations    = translations / np.max(translations, axis=0)

	# Split into training and validation sets
	X_train, X_val, y_train, y_val = train_test_split(times, translations, test_size=0.2, random_state=42)

	# return the training and validation sets
	return X_train, X_val, y_train, y_val

# Example usage
object_name = 'pSphere1'
animation_data = extract_animation_data(object_name)
X_train, X_val, y_train, y_val = preprocess_data(animation_data)

# ----------------------------------------------------------------------------------------------
# Train your model
# ----------------------------------------------------------------------------------------------
import tensorflow as tf

def create_model():
	model = tf.keras.models.Sequential([
		tf.keras.layers.Dense(64, activation='relu', input_shape=[1]),
		tf.keras.layers.Dense(64, activation='relu'),
		tf.keras.layers.Dense(3)
	])

	model.compile(optimizer='adam', loss='mean_squared_error')
	return model

def train_model(model, X_train, y_train, X_val, y_val):
	model.fit(X_train, y_train, validation_data=(X_val, y_val), epochs=100, verbose=0)
	return model

# Example usage
model = create_model()
model = train_model(model, X_train, y_train, X_val, y_val)
print('Model trained successfully!')

# ----------------------------------------------------------------------------------------------
# Generate new animation
# ----------------------------------------------------------------------------------------------
def generate_animation(model, object_name):
	# Generate new keyframes
	new_keyframes = np.linspace(0, 1, 100)
	new_keyframes = new_keyframes.reshape(-1, 1)

	# Predict translations at each keyframe
	predictions = model.predict(new_keyframes)
	predictions = predictions * np.max(animation_data, axis=0)[1]

	# Set the new keyframes on the object
	for keyframe, translation in zip(new_keyframes, predictions):
		cmds.setKeyframe(object_name, time=keyframe[0] * np.max(animation_data, axis=0)[0], attribute='translate', value=translation)

# Example usage
generate_animation(model, object_name)
print('New animation generated successfully!')

# ----------------------------------------------------------------------------------------------

	


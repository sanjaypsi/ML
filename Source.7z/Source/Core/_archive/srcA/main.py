import tensorflow as tf
import numpy as np
from termcolor import colored

print(colored("TensorFlow version:"+ tf.__version__, 'green'))
print(colored("NumPy version:" + np.__version__, 'green'))

import maya.cmds as cmds

def create_bouncingBall():
    # Create a sphere to act as the ball
    ball = cmds.polySphere(name='bouncingBall', radius=1)[0]

    # Set keyframes for the bounce animation
    cmds.setKeyframe(ball, attribute='translateY', value=0, t=0)
    cmds.setKeyframe(ball, attribute='translateY', value=10, t=10)
    cmds.setKeyframe(ball, attribute='translateY', value=0, t=20)
    
    # Set the tangents to linear so the ball moves evenly between keyframes
    cmds.selectKey(ball, time=(0, 20), attribute='translateY')
    cmds.keyTangent(inTangentType='linear', outTangentType='linear')
    
    # Loop the animation
    cmds.playbackOptions(loop='continuous')
    cmds.currentTime(0)

# Call the function to create and animate the bouncing ball
create_bouncingBall()

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn import linear_model

# Create a simple DataFrame
data = {
    'area':     [2600, 3000, 3200, 36000, 4000],
    'price':    [550000, 565000, 610000, 680000, 725000],
}

df = pd.DataFrame(data)
plt.xlabel('area(sq ft)')
plt.ylabel('price(US$)')
plt.scatter(df.area, df.price, color='red', marker='+')
# plt.show()

reg = linear_model.LinearRegression()
reg.fit(df[['area']], df.price)
linear_model.LinearRegression(copy_X=True, fit_intercept=True, n_jobs=1, normalize=True)
print(reg.predict([[5000]]))
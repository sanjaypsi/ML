import maya.cmds as cmds
import csv

# Specify the name of the object to export animation data from
object_name = 'bouncingBall'

# Get the total number of frames in the animation
start_frame = int(cmds.playbackOptions(query=True, minTime=True))
end_frame = int(cmds.playbackOptions(query=True, maxTime=True))

# Open a CSV file to write the data
with open('E:/ML/Source/Core/animation_data.csv', mode='w', newline='') as file:
    writer = csv.writer(file)
    # Write the header
    writer.writerow(['Frame', 'TranslateX', 'TranslateY', 'TranslateZ'])

    # Loop through each frame and get the position of the object
    for frame in range(start_frame, end_frame + 1):
        cmds.currentTime(frame)
        position = cmds.xform(object_name, query=True, translation=True, worldSpace=True)
        writer.writerow([frame, position[0], position[1], position[2]])

print('Animation data exported successfully!')


import tensorflow as tf
import numpy as np
import pandas as pd

# Load the data from the CSV file
data = pd.read_csv('E:/ML/Source/Core/animation_data.csv')

# Prepare the input and output data
X = data[['TranslateX', 'TranslateY', 'TranslateZ']].values[:-1]  # input (current position)
Y = data[['TranslateX', 'TranslateY', 'TranslateZ']].values[1:]   # output (next position)

# Print the shape of the training data
print("Shape of X (training input):", X.shape)

# Build a simple neural network model
model = tf.keras.models.Sequential([
    tf.keras.layers.Dense(64, activation='relu', input_shape=(3,)),
    tf.keras.layers.Dense(64, activation='relu'),
    tf.keras.layers.Dense(3)
])

# Compile the model
model.compile(optimizer='adam', loss='mse')

# Train the model
model.fit(X, Y, epochs=200)

# Save the model
model.save('E:/ML/Source/Core/bouncing_ball_model.keras')

# Load the trained model
model = tf.keras.models.load_model('E:/ML/Source/Core/bouncing_ball_model.keras')

# Example current position (reshape to match the expected input shape)
current_position = np.array([[0.5, 1.0, 0.0]])  # Example current position

# Ensure the input shape matches the model's expectations (1 sample, 3 features)
current_position = current_position.reshape((1, 3))

# Predict the next position
next_position = model.predict(current_position)

print("Predicted next position:", next_position)

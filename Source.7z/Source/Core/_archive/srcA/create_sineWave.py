'''
Create a Python script that uses TensorFlow and integrates with Maya's functionality.
Here’s an example script that loads TensorFlow within Maya:

from importlib import reload
from Core import create_sineWave
reload(create_sineWave)
create_sineWave.curve_sineWave()

'''

import tensorflow as tf
import maya.cmds as cmds

def curve_sineWave():
    # Generate a sine wave using TensorFlow
    cmds.file(new=True, force=True)
    x = tf.linspace(5.0, 40.0, 100)

    print('x:', x)
    y = tf.sin(x)

    # Create a curve in Maya
    curve_points = [(i, float(y[i].numpy()), 0) for i in range(len(y))]
    curve = cmds.curve(p=curve_points)

    #return curve

import tensorflow as tf
import numpy as np
import pandas as pd

# Load the data from the CSV file
data = pd.read_csv('E:/ML/Source/Core/animation_data.csv')

# Prepare the input and output data
X = data[['TranslateX', 'TranslateY', 'TranslateZ']].values[:-1]  # input (current position)
Y = data[['TranslateX', 'TranslateY', 'TranslateZ']].values[1:]   # output (next position)

# Build a simple neural network model
model = tf.keras.models.Sequential([
    tf.keras.layers.Dense(64, activation='relu', input_shape=(3,)),
    tf.keras.layers.Dense(64, activation='relu'),
    tf.keras.layers.Dense(3)
])

# Compile the model
model.compile(optimizer='adam', loss='mse')
# Train the model
model.fit(X, Y, epochs=200)
# Save the model
model.save('bouncing_ball_model.keras')

import pandas as pd

# Create a simple DataFrame
data = {
    'days':     ['1/1/2024', '1/2/2024', '1/3/2024'],
    'temp':     [40, 50, 60],
    'winspeed': [50, 200, 500]
}
df = pd.DataFrame(data)
# print(df.shape)
# print(df.columns)
# print(df.head())
# print(df.tail())
print(df.describe())
# print(df.info())
# print(df['temp'])
# print(df['temp'].mean())
# print(df['temp'].max())
# print(df['temp'].min())

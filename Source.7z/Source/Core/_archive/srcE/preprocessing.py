import json
import numpy as np
import tensorflow as tf
from sklearn.model_selection import train_test_split
import os
import matplotlib.pyplot as plt

# Path to the JSON file
scriptpath  = os.path.dirname(__file__)
filepath    = os.path.join(scriptpath, 'data', 'positionsA.json')
output_path = os.path.join(scriptpath, 'data', 'predicted_output.json')

# Load JSON data
with open(filepath) as json_file:
    data = json.load(json_file)

# Extract features and labels
def extract_features_labels(data):
    features = []
    labels = []
    for joint in data:
        joint_data = data[joint]
        prev_frame_data = None
        for frame_data in joint_data:
            if prev_frame_data is not None:
                # Calculate velocities
                translation_velocity = [
                    frame_data['translation'][i] - prev_frame_data['translation'][i] for i in range(3)
                ]
                rotation_velocity = [
                    frame_data['rotation'][i] - prev_frame_data['rotation'][i] for i in range(3)
                ]
                features.append(prev_frame_data['translation'] + prev_frame_data['rotation'])
                labels.append(translation_velocity + rotation_velocity)
            prev_frame_data = frame_data
    return np.array(features), np.array(labels)

features, labels = extract_features_labels(data)

# Normalize features and labels
features = (features - np.mean(features, axis=0)) / np.std(features, axis=0)
labels = (labels - np.mean(labels, axis=0)) / np.std(labels, axis=0)

# Split the data into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(features, labels, test_size=0.2, random_state=42)

# Reshape data for LSTM input
X_train = X_train.reshape((X_train.shape[0], 1, X_train.shape[1]))
X_test  = X_test.reshape((X_test.shape[0], 1, X_test.shape[1]))

# Ensure y_train and y_test are 2D arrays with shape (batch_size, 6)
y_train = y_train.reshape((y_train.shape[0], 6))
y_test  = y_test.reshape((y_test.shape[0], 6))

# Build the LSTM model
model = tf.keras.Sequential([
    tf.keras.layers.LSTM(50, input_shape=(X_train.shape[1], X_train.shape[2]), return_sequences=True),
    tf.keras.layers.LSTM(50),
    tf.keras.layers.Dense(3)  # 3 for translation velocity and 3 for rotation velocity
])

model.compile(loss='mse', optimizer='adam')

# Train the model
model.fit(X_train, y_train, epochs=50, batch_size=32, validation_data=(X_test, y_test), verbose=2, shuffle=False)

# Evaluate the model
loss = model.evaluate(X_test, y_test, verbose=2)
print(f"Test loss: {loss}")

# Make predictions
predictions = model.predict(X_test)

# Save predictions to JSON
def save_predictions_to_json(predictions, output_path, joint_names):
    prediction_data = {}
    for i, joint in enumerate(joint_names):
        prediction_data[joint] = []
        for j in range(len(predictions)):
            prediction_data[joint].append({
                'frame': j + 36,  # Adjusting the frame range assumption to start from frame 36
                'translation': predictions[j][:3].tolist(),
                'rotation': predictions[j][3:].tolist()
            })
    
    with open(output_path, 'w') as outfile:
        json.dump(prediction_data, outfile, indent=4)

joint_names = list(data.keys())
save_predictions_to_json(predictions, output_path, joint_names)


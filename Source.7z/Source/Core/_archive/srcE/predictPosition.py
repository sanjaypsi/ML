import json
import numpy as np
import tensorflow as tf
from sklearn.model_selection import train_test_split
import os

# Path to the JSON file
scriptpath  = os.path.dirname(__file__)
filepath    = os.path.join(scriptpath, 'data', 'positionsA.json')
output_path = os.path.join(scriptpath, 'data', 'predicted_output.json')

# Train your model to perdict animation base on the data in positionsA.json file and save the model to a file json format which can import to maya to apply the animation

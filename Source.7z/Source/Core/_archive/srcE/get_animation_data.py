import maya.cmds as cmds
import json
import os

# Path to the JSON file
scriptpath  = os.path.dirname(__file__)
filepath    = os.path.join(scriptpath, 'data', 'positionsA.json')

def export_animation_to_json(start_frame, end_frame):
    # Get all joints in the scene
    joints = cmds.ls(type="joint")
    
    animation_data = {}
    
    for joint in joints:
        joint_data = []
        for frame in range(start_frame, end_frame + 1):
            cmds.currentTime(frame)
            translation = cmds.xform(joint, q=True, ws=True, t=True)
            rotation = cmds.xform(joint, q=True, ws=True, ro=True)
            joint_data.append({
                'frame': frame,
                'translation': translation,
                'rotation': rotation
            })
        animation_data[joint] = joint_data
    
    with open(filepath, 'w') as outfile:
        json.dump(animation_data, outfile, indent=4)

# # Usage
# from importlib import reload
# from Core import get_animation_data
# reload(get_animation_data)
# start_frame     = 1
# end_frame       = 40
# get_animation_data.export_animation_to_json(start_frame, end_frame)
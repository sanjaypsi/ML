''' 
Step 4: Using the Model to Generate Animation
Load the trained model and generate predictions.
Apply these predictions as keyframes in Maya.
Here's an example script to apply the predictions:

from importlib import reload
from Core import updateAnim
reload(updateAnim)
updateAnim.apply_animation_from_json()

'''

import maya.cmds as cmds
import json
import os

# Path to the JSON file
scriptpath  = os.path.dirname(__file__)
input_path = os.path.join(scriptpath, 'data', 'predictions.json')

def apply_animation_from_json():
    with open(input_path, 'r') as infile:
        animation_data = json.load(infile)
    
    for joint, frames_data in animation_data.items():
        for frame_data in frames_data:
            frame       = frame_data['frame']
            #translation = frame_data['translation']
            rotation    = frame_data['rotation']
            
            # cmds.setKeyframe(joint, time=frame, attribute='translateX', value=translation[0])
            # cmds.setKeyframe(joint, time=frame, attribute='translateY', value=translation[1])
            # cmds.setKeyframe(joint, time=frame, attribute='translateZ', value=translation[2])
            cmds.setKeyframe(joint, time=frame, attribute='rotateX', value=rotation[0])
            cmds.setKeyframe(joint, time=frame, attribute='rotateY', value=rotation[1])
            cmds.setKeyframe(joint, time=frame, attribute='rotateZ', value=rotation[2])

# Usage

from stable_baselines3 import PPO

# Load the saved model
loaded_model = PPO.load('E:/ML/Source/ppo_maya_animationA.zip')
import gym
from gym import spaces
import numpy as np
from stable_baselines3 import PPO
from stable_baselines3.common.vec_env import DummyVecEnv

class BouncingBallEnv(gym.Env):
    def __init__(self):
        super(BouncingBallEnv, self).__init__()
        self.gravity = 9.81  # Acceleration due to gravity (m/s^2)
        self.ball_radius = 0.1  # Radius of the ball
        self.floor_position = 0.0  # Position of the floor (y-axis)

        # Ball properties
        self.ball_position = np.array([0.0, 1.0])  # Initial position (x, y)
        self.ball_velocity = np.array([0.0, 0.0])  # Initial velocity (vx, vy)

        # Action space: Adjust velocity in x and y directions
        self.action_space = spaces.Box(low=-1, high=1, shape=(2,), dtype=np.float32)

        # Observation space: Ball position and velocity
        self.observation_space = spaces.Box(low=-10, high=10, shape=(4,), dtype=np.float32)

    def reset(self):
        # Reset ball position and velocity
        self.ball_position = np.array([0.0, 1.0])
        self.ball_velocity = np.array([0.0, 0.0])
        return self._get_observation()

    def step(self, action):
        # Apply action to adjust ball velocity
        self.ball_velocity += action

        # Update ball position based on velocity
        self.ball_position += self.ball_velocity

        # Check collision with the floor
        if self.ball_position[1] <= self.ball_radius + self.floor_position:
            self.ball_position[1] = self.ball_radius + self.floor_position
            self.ball_velocity[1] *= -0.9  # Bounce with some energy loss

        # Calculate reward
        reward = self._calculate_reward()

        # Check termination condition (for simplicity, we can define a maximum episode length)
        done = False
        if np.abs(self.ball_velocity[1]) < 0.01:  # Ball stops bouncing
            done = True

        return self._get_observation(), reward, done, {}

    def _get_observation(self):
        return np.concatenate((self.ball_position, self.ball_velocity))

    def _calculate_reward(self):
        # Reward based on staying within a certain height range
        if self.ball_position[1] > 1.0:  # Reward for bouncing higher
            reward = 1.0
        elif self.ball_position[1] < 0.5:  # Penalize for bouncing too low
            reward = -1.0
        else:
            reward = 0.0
        return reward

    def render(self, mode='human'):
        # Implement visualization if needed
        pass

    def close(self):
        pass

# Test the environment
env = BouncingBallEnv()
observation = env.reset()

for _ in range(100):
    action = env.action_space.sample()  # Random action for testing
    observation, reward, done, _ = env.step(action)
    if done:
        observation = env.reset()

env.close()

# Training with Stable Baselines 3
def make_env():
    return BouncingBallEnv()

# Create multiple environments for vectorized training
env = DummyVecEnv([make_env])

# Define and train the PPO agent
model = PPO('MlpPolicy', env, verbose=1)
model.learn(total_timesteps=100000)

# Save the trained model
model.save('ppo_bouncing_ball')

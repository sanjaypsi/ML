from stable_baselines3 import PPO
from stable_baselines3.common.env_checker import check_env
import json
from mock_maya_env import MockMayaAnimationEnv  # Ensure this import is correct
import numpy as np

# Path to the JSON file containing the initial position
output_file = 'E:/ML/Source/Core/data/initial_position.json'

# Load initial position from the JSON file
with open(output_file, 'r') as f:
    initial_position = json.load(f)['initial_position']

# Instantiate the environment with the initial position and frame range
env = MockMayaAnimationEnv(start_frame=1, end_frame=100, initial_position=initial_position)

# Check the environment to ensure it follows the Gym API
check_env(env)

# Instantiate the PPO agent with an MLP policy
model = PPO('MlpPolicy', env, verbose=1)

# Train the agent for 10,000 timesteps
model.learn(total_timesteps=10000)

# Save the trained model to a file
model.save('ppo_maya_animation')

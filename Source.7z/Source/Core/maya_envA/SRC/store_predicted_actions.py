from stable_baselines3 import PPO
from stable_baselines3.common.env_checker import check_env
import json
from mock_maya_env import MockMayaAnimationEnv

# Load initial position from file
with open('Core/data/initial_position.json', 'r') as f:
    initial_position = json.load(f)['initial_position']

# Load the trained model (this will automatically handle the zip file or directory)


# # Create the environment
# env = MockMayaAnimationEnv(start_frame=1, end_frame=100, initial_position=initial_position)
env = MockMayaAnimationEnv(start_frame=1, end_frame=100, initial_position=initial_position)

# Check the environment to ensure it follows the Gymnasium API
check_env(env)

# Instantiate the PPO agent with an MLP policy
model = PPO('MlpPolicy', env, verbose=1)

# Train the agent for 10,000 timesteps
model.learn(total_timesteps=100000)

# Save the trained model to a file
model.save('Core/data/ppo_maya_animationA')

# load the trained model
model = PPO.load('Core/data/ppo_maya_animationA.zip')

# Reset the environment
obs, _ = env.reset()
predicted_actions = []
for _ in range(env.end_frame - env.start_frame):
    action, _states = model.predict(obs)
    obs, rewards, done, _, _ = env.step(action)
    predicted_actions.append({
        'frame': env.current_frame,
        'action': action.tolist(),
        'position': obs.tolist()
    })

    if done:
        break

# Save the predicted actions to a JSON file
with open('Core/data/predicted_actions.json', 'w') as f:
    json.dump(predicted_actions, f, indent=4)
import gymnasium as gym
from gymnasium import spaces
import numpy as np
from stable_baselines3 import PPO
from stable_baselines3.common.env_checker import check_env
import json

class MockMayaAnimationEnv(gym.Env):
    def __init__(self, start_frame, end_frame, initial_position):
        super(MockMayaAnimationEnv, self).__init__()
        self.start_frame = start_frame
        self.end_frame = end_frame
        self.current_frame = start_frame
        self.initial_position = initial_position  # Correct initialization
        self.position = np.array(initial_position, dtype=np.float32)

        self.action_space = spaces.Box(low=-1, high=1, shape=(3,), dtype=np.float32)
        self.observation_space = spaces.Box(low=-10, high=10, shape=(3,), dtype=np.float32)

    def reset(self, seed=None, options=None):
        super().reset(seed=seed)
        self.current_frame = self.start_frame
        self.position = np.array(self.initial_position, dtype=np.float32)
        return self.position, {}

    def step(self, action):
        self.current_frame += 1
        self.position += action

        target_position = np.array([5.0, 5.0, 5.0], dtype=np.float32)
        reward = -float(np.linalg.norm(self.position - target_position))  # Ensure reward is a float

        terminated = self.current_frame >= self.end_frame
        truncated = False  # Assuming no truncation for simplicity

        return self.position, reward, terminated, truncated, {}

    def render(self, mode='human'):
        pass

    def close(self):
        pass

# # Path to the JSON file containing the initial position
# output_file = 'E:/ML/Source/Core/data/initial_position.json'

# # Load initial position from the JSON file
# with open(output_file, 'r') as f:
#     initial_position = json.load(f)['initial_position']

# # Ensure the initial position is of type float32
# initial_position = [float(pos) for pos in initial_position]

# # Instantiate the environment with the initial position and frame range
# env = MockMayaAnimationEnv(start_frame=1, end_frame=100, initial_position=initial_position)

# # Check the environment to ensure it follows the Gymnasium API
# check_env(env)

# # Instantiate the PPO agent with an MLP policy
# model = PPO('MlpPolicy', env, verbose=1)

# # Train the agent for 10,000 timesteps
# model.learn(total_timesteps=100000)

# # Save the trained model to a file
# model.save('Core/data/ppo_maya_animationA')

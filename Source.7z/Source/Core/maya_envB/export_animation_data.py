import maya.cmds as cmds
import json

def export_animation_data(start_frame, end_frame, file_path):
    animation_data = {}
    for frame in range(start_frame, end_frame + 1):
        cmds.currentTime(frame)
        animation_data[frame] = {}
        for obj in cmds.ls(selection=True):
            translation = cmds.getAttr(f"{obj}.translate")[0]
            rotation = cmds.getAttr(f"{obj}.rotate")[0]
            animation_data[frame][obj] = {
                'translation': translation,
                'rotation': rotation
            }

    with open(file_path, 'w') as f:
        json.dump(animation_data, f, indent=4)


export_animation_data(1, 100, 'E:\ML\Source\Core\data\animation_data.json')
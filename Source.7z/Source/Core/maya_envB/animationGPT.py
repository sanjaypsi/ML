import torch
import torch.nn as nn
import numpy as np
import json

# Define the model architecture
class SimpleModel(nn.Module):
    def __init__(self):
        super(SimpleModel, self).__init__()
        self.fc1 = nn.Linear(10, 50)
        self.fc2 = nn.Linear(50, 20)
        self.fc3 = nn.Linear(20, 5)

    def forward(self, x):
        x = torch.relu(self.fc1(x))
        x = torch.relu(self.fc2(x))
        x = self.fc3(x)
        return x

# Instantiate the model
model = SimpleModel()

# Load the state dictionary
model_path = 'E:/ML/Source/Core/data/motion_predictor.pth'
state_dict = torch.load(model_path)
model.load_state_dict(state_dict)

# Set the model to evaluation mode
model.eval()

# Function to preprocess data
def preprocess_data(animation_data):
    data = []
    for frame, objects in animation_data.items():
        for obj, attributes in objects.items():
            data.append(attributes['translation'] + attributes['rotation'])
    data = np.array(data)
    data = (data - data.mean(axis=0)) / data.std(axis=0)
    return data

# Load and preprocess animation data
data_path = 'E:/ML/Source/Core/data/animation_data.json'
with open(data_path) as f:
    animation_data = json.load(f)

processed_data = preprocess_data(animation_data)

# Convert to tensor and make predictions
with torch.no_grad():
    predictions = model(torch.tensor(processed_data).float())

# Convert predictions to numpy array for further processing if needed
predictions = predictions.numpy()

# Print or process predictions as required
print(predictions)

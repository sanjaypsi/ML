import maya.cmds as cmds
import json
import numpy as np
from sklearn.model_selection import train_test_split
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, LSTM


output_file  = "E:/ML/Source/Core/data/animation_data.json"
input_file  = "E:/ML/Source/Core/data/animation_data.json"

# Function to export animation data
def export_animation_data(start_frame, end_frame, output_file):
    animation_data = {}
    for frame in range(start_frame, end_frame + 1):
        cmds.currentTime(frame)
        frame_data = {}
        for obj in cmds.ls(type='transform'):
            frame_data[obj] = cmds.getAttr(obj + '.translate')[0]
        animation_data[frame] = frame_data
    with open(output_file, 'w') as f:
        json.dump(animation_data, f)

# Function to prepare data for machine learning
def prepare_data(input_file):
    with open(input_file, 'r') as f:
        data = json.load(f)
    frames = sorted(data.keys(), key=int)
    X = []
    y = []
    for i in range(len(frames) - 10):
        X_seq = []
        for j in range(i, i + 10):
            frame_num = int(frames[j])
            position = data[frames[j]]['pCube1']
            X_seq.append(position + [frame_num])
        X.append(X_seq)
        y.append(data[frames[i + 10]]['pCube1'])
    X = np.array(X)
    y = np.array(y)
    return train_test_split(X, y, test_size=0.2, random_state=42)

# Function to train the model
def train_model(X_train, y_train, X_test, y_test):
    input_shape = (X_train.shape[1], X_train.shape[2])
    model = Sequential([
        LSTM(50, activation='relu', input_shape=input_shape),
        Dense(3)
    ])
    model.compile(optimizer='adam', loss='mse')
    model.fit(X_train, y_train, epochs=200, validation_data=(X_test, y_test))
    return model

# Function to predict future frames
def predict_future_frames(model, initial_sequence, num_future_frames):
    predictions = []
    current_sequence = initial_sequence

    for i in range(num_future_frames):
        prediction = model.predict(np.array([current_sequence]))[0]
        predictions.append(prediction.tolist())

        next_frame_num = current_sequence[-1][-1] + 1
        next_input = prediction.tolist() + [next_frame_num]
        current_sequence = current_sequence[1:] + [next_input]

    return predictions

# Function to import animation data back into Maya
def import_animation_data(predictions, start_frame):
    for i, frame_data in enumerate(predictions):
        frame = start_frame + i
        cmds.currentTime(frame)
        x, y, z = float(frame_data[0]), float(frame_data[1]), float(frame_data[2])
        cmds.setKeyframe('pCube1', attribute='translateX', value=x)
        cmds.setKeyframe('pCube1', attribute='translateY', value=y)
        cmds.setKeyframe('pCube1', attribute='translateZ', value=z)

# Export animation data from Maya
export_animation_data(1, 40, 'animation_data.json')

# Prepare data for machine learning
X_train, X_test, y_train, y_test = prepare_data('animation_data.json')

# Train the model
model = train_model(X_train, y_train, X_test, y_test)

# Make predictions
# Use the last 10 frames from the test set as the initial sequence
initial_sequence = X_test[0]  # Example sequence from the test set
num_future_frames = 20  # Number of future frames to predict
predictions = predict_future_frames(model, initial_sequence, num_future_frames)

# Import predictions back into Maya
import_animation_data(predictions, 41)

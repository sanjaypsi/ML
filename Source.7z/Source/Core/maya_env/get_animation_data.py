import maya.cmds as cmds
import json
import os

# Path to the JSON file
scriptpath    = os.path.dirname(__file__)
output_file   = os.path.join(scriptpath, 'data', 'animation_data.json')

def export_animation_data(start_frame, end_frame):
    animation_data = {}
    for frame in range(start_frame, end_frame + 1):
        cmds.currentTime(frame)
        frame_data = {}
        for obj in cmds.ls(sl=True):
            frame_data[obj] = cmds.getAttr(obj + '.translate')[0]
        animation_data[frame] = frame_data
    with open(output_file, 'w') as f:
        json.dump(animation_data, f)

# # # Usage
# from importlib import reload
# from Core import get_animation_data
# reload(get_animation_data)
# start_frame     = 1
# end_frame       = 40
# get_animation_data.export_animation_data(start_frame, end_frame)
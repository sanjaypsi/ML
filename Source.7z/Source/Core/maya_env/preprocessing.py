import json
import numpy as np
import torch
from torch.utils.data import DataLoader, Dataset
import os

scriptpath  = os.path.dirname(__file__)
filepath    = os.path.join(scriptpath, 'data', 'animation_data.json')
output_path = os.path.join(scriptpath, 'data', 'predicted_output.json')

class AnimationDataset(Dataset):
    def __init__(self, data, sequence_length):
        self.data = data
        self.sequence_length = sequence_length
        self.process_data()

    def process_data(self):
        sequences = []
        labels = []
        for joint in self.data:
            for attr in self.data[joint]:
                keys = list(self.data[joint][attr].keys())
                values = list(self.data[joint][attr].values())
                for i in range(len(values) - self.sequence_length):
                    sequences.append(values[i:i+self.sequence_length])
                    labels.append(values[i+self.sequence_length])
        self.sequences = np.array(sequences)
        self.labels = np.array(labels)

    def __len__(self):
        return len(self.sequences)

    def __getitem__(self, idx):
        return torch.tensor(self.sequences[idx], dtype=torch.float32), torch.tensor(self.labels[idx], dtype=torch.float32)

# Load the data
with open(filepath, 'r') as infile:
    animation_data = json.load(infile)

# Prepare dataset
sequence_length = 10
dataset     = AnimationDataset(animation_data, sequence_length)
dataloader  = DataLoader(dataset, batch_size=32, shuffle=True)


import torch.nn as nn

class LSTMModel(nn.Module):
    def __init__(self, input_size, hidden_size, output_size, num_layers=1):
        super(LSTMModel, self).__init__()
        self.lstm = nn.LSTM(input_size, hidden_size, num_layers, batch_first=True)
        self.fc = nn.Linear(hidden_size, output_size)

    def forward(self, x):
        h0 = torch.zeros(1, x.size(0), hidden_size).to(x.device)
        c0 = torch.zeros(1, x.size(0), hidden_size).to(x.device)
        out, _ = self.lstm(x, (h0, c0))
        out = self.fc(out[:, -1, :])
        return out

input_size = 1  # Adjust according to your data
hidden_size = 50
output_size = 1
model = LSTMModel(input_size, hidden_size, output_size)


import torch.optim as optim

criterion = nn.MSELoss()
optimizer = optim.Adam(model.parameters(), lr=0.001)

num_epochs = 50
model.train()

for epoch in range(num_epochs):
    for sequences, labels in dataloader:
        optimizer.zero_grad()
        outputs = model(sequences.unsqueeze(-1))
        loss = criterion(outputs, labels.unsqueeze(-1))
        loss.backward()
        optimizer.step()
    print(f'Epoch [{epoch+1}/{num_epochs}], Loss: {loss.item():.4f}')

import torch
import json

# Assuming `animation_data` and `sequence_length` are already defined

# Example joint and attribute to test
joint = 'joint1'
attr = 'translateX'

# Extract the last `sequence_length` values for the test sequence
your_test_sequence = animation_data[joint][attr]
test_sequence_values = list(your_test_sequence.values())[-sequence_length:]

# Convert to tensor and adjust dimensions
test_sequence = torch.tensor(test_sequence_values, dtype=torch.float32).unsqueeze(0).unsqueeze(-1)

# Evaluate the model
model.eval()

# Predict the next 100 frames
predicted_sequence = []
for i in range(100):
    with torch.no_grad():
        output = model(test_sequence)
        
    # Ensure output has the correct dimensions
    output = output.squeeze(-1).unsqueeze(0).unsqueeze(-1)

    # Update the test sequence
    test_sequence = torch.cat((test_sequence[:, 1:, :], output), dim=1)
    
    # Append the predicted value to the predicted sequence
    predicted_value = output.squeeze().item()
    predicted_sequence.append(predicted_value)

# Output the predicted sequence
print(predicted_sequence)




''' 
Step 4: Using the Model to Generate Animation
Load the trained model and generate predictions.
Apply these predictions as keyframes in Maya.
Here's an example script to apply the predictions:

from importlib import reload
from Core import updateAnim
reload(updateAnim)
updateAnim.apply_animation_from_json()

'''

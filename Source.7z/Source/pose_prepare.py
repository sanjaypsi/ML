import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense

# Load the CSV file
csv_file = 'E:/ML/Source/Tensorflow/exported_joints.csv'
data = pd.read_csv(csv_file)

# Extract rotation values
rotations = data.iloc[:, 1:].values  # Exclude frame numbers

# Normalize the data
scaler = MinMaxScaler()
normalized_rotations = scaler.fit_transform(rotations)

# Create sequences for LSTM
sequence_length = 10  # Define the sequence length
num_features = normalized_rotations.shape[1]

# Create sequences and corresponding targets
sequences = []
for i in range(len(normalized_rotations) - sequence_length):
    sequences.append(normalized_rotations[i:i + sequence_length])

sequences = np.array(sequences)
X = sequences[:, :-1, :]
y = sequences[:, -1, :]

# Build the model
model = Sequential([
    LSTM(128, activation='relu', input_shape=(sequence_length - 1, num_features)),
    Dense(num_features)
])

model.compile(optimizer='adam', loss='mse')
model.summary()

# Train the model
model.fit(X, y, epochs=50, batch_size=32)


def generate_in_between_poses(model, start_pose, middle_pose, end_pose, num_in_betweens):
    def interpolate_poses(pose1, pose2, steps):
        return [(pose1 + (pose2 - pose1) * (i / (steps + 1))) for i in range(1, steps + 1)]

    in_betweens = []

    # Interpolate from start to middle pose
    in_betweens += interpolate_poses(start_pose, middle_pose, num_in_betweens)

    # Interpolate from middle to end pose
    in_betweens += interpolate_poses(middle_pose, end_pose, num_in_betweens)

    return np.array(in_betweens)

# Example poses (replace with actual data)
start_pose = rotations[0]  # Replace with actual start pose
middle_pose = rotations[len(rotations) // 2]  # Replace with actual middle pose
end_pose = rotations[-1]  # Replace with actual end pose

num_in_betweens = 5  # Number of in-between poses you want
in_between_poses = generate_in_between_poses(model, start_pose, middle_pose, end_pose, num_in_betweens)

# Inverse transform to original scale
original_scale_poses = scaler.inverse_transform(in_between_poses)

print("Generated in-between poses:")
print(original_scale_poses)

# Save the generated poses to a CSV file
output_file = 'E:/ML/Source/Tensorflow/generated_poses.csv'
pd.DataFrame(original_scale_poses).to_csv(output_file, index=False)


